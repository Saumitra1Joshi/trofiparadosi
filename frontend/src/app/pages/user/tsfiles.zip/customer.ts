export class Customer {
    customerName:String;
        phoneno: String;
        email: String;
        address:String;
        customerid:number;
}
