export class OrderInItem {
    
     id:number;
     imageUrl: string;
    unitPrice: number;
     quantity: number;
     productId: number;
     productname:string;
}