export class restaurant{
    constructor(
        public id:number,
        public restaurantname:string,
        public restype:string,
        public ratings:string,
        public pricetag:string,
        public imageurl:string,
        public time:string
    ){
    }
}